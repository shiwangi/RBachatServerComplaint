package com.example.shiwangi.dataplan;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import com.example.shiwangi.dataplan.utils.NetworkCalls;
import org.json.JSONObject;


public class PhoneNumber extends Activity implements View.OnClickListener {
    String phoneNumber;
    EditText et;
    private String IP_ADDRESS = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //Check if the user has logged in before move to the next page directly
        SharedPreferences settings = getSharedPreferences("MyPrefsFile", 0);
        boolean hasLoggedIn = settings.getBoolean("hasLoggedIn", false);
        if(hasLoggedIn)
        {
            Intent intent = new Intent(this , FetchCallTypeActivity.class);
            intent.putExtra("parent", "PhoneNumber");
            startActivity(intent);
        }

        //If Not logged in fetch the Phone Number

        setContentView(R.layout.activity_phone_number);
        et =(EditText) findViewById(R.id.editText1);
        Button b =(Button) findViewById(R.id.submit);
        b.setOnClickListener(this);

    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_phone_number, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onClick(View v) {
        switch(v.getId())
        {
            case R.id.submit:phoneNumber = String.valueOf(et.getText());
                                            if(phoneNumber.length() != 10){
                                                Toast toast = Toast.makeText(getApplicationContext(), "Incorrect Phone number", Toast.LENGTH_SHORT);
                                                toast.show();
                                                break;
                                            }
                                            //Adding the Number to the logFile to automate logIn next Time
                                            SharedPreferences settings = getSharedPreferences("MyPrefsFile", 0); // 0 - for private mode
                                            SharedPreferences.Editor editor = settings.edit();
                                            editor.putBoolean("hasLoggedIn", true);
                                            editor.putString("phoneNumber", phoneNumber);
                                            editor.commit();    // Commit the edits!
                                            //TODO:Send query to IP FOR Operator + State
                NetworkCalls networkCalls = new NetworkCalls();
                JSONObject jobj = networkCalls.getJsonObjectFrom(IP_ADDRESS);
                                            //TODO:If Operator not found go to OperatorNotFound Activity

                                            Intent intent = new Intent(this , FetchCallTypeActivity.class);
                                            intent.putExtra("parent", "PhoneNumber");
                                            startActivity(intent);
                                            break;
        }


    }
}
