package com.example.shiwangi.dataplan;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.app.Activity;
import android.content.Context;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.example.shiwangi.dataplan.utils.CallType;
import com.example.shiwangi.dataplan.utils.GetLog;
import com.example.shiwangi.dataplan.utils.Values;
import com.github.lzyzsd.circleprogress.ArcProgress;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Locale;

public class FetchCallTypeActivity extends Activity implements OnClickListener {

    ArcProgress pBar, pBar2;
    ProgressBar progBar;
    ProgressBar lp, lp2;
    TextView fromDate;
    Button pressed, nonPressed, fetchButton;
    private Context mContext;
    public static String myOperator, myState;
    private SimpleDateFormat dateFormatter;
    private DatePickerDialog fromDatePickerDialog;
    private static GetLog mlog;
    CallType local, std;
    static int flag = 0;
    static String phoneNumber;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fetch_call_type);
        Bundle extra = getIntent().getExtras();
        String prevIntent = extra.getString("parent");

        if(prevIntent.equals("OperatorNotFound")){
            myOperator = extra.getString("myOperator");
            myState = extra.getString("myState");
        }

        fromDate = (TextView)findViewById(R.id.fromDate);
        fromDate.setOnClickListener(this);
        SharedPreferences settings = getSharedPreferences("MyPrefsFile", 0);
        phoneNumber = settings.getString("phoneNumber", null);
        String date = settings.getString("fromDate", "03-01-2015");
        fromDate.setText("Your calls since " + date);
        mlog = new GetLog(getApplicationContext(), phoneNumber,date);
        mContext = this;

        local = new CallType(new Values(0, 0), new Values(0, 0));
        std = new CallType(new Values(0, 0), new Values(0, 0));

        pressed = (Button) findViewById(R.id.pressed_btn);
        nonPressed = (Button) findViewById(R.id.nonpressed_btn);

        fetchButton = (Button) findViewById(R.id.fetch_plan);

        nonPressed.setOnClickListener(this);
        setFromDate();
    }

    private void setFromDate() {
        dateFormatter = new SimpleDateFormat("dd-MM-yyyy", Locale.US);

        Calendar newCalendar = Calendar.getInstance();
        fromDatePickerDialog = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {

            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                Calendar newDate = Calendar.getInstance();
                newDate.set(year, monthOfYear, dayOfMonth);
                fromDate.setText("Your calls since " + dateFormatter.format(newDate.getTime()));
                SharedPreferences settings = getSharedPreferences("MyPrefsFile", 0); // 0 - for private mode
                SharedPreferences.Editor editor = settings.edit();
                editor.putString("fromDate",dateFormatter.format(newDate.getTime()));
                // Commit the edits!
                editor.commit();

                mlog = new GetLog(getApplicationContext(), phoneNumber,dateFormatter.format(newDate.getTime()));
            }

        },newCalendar.get(Calendar.YEAR), newCalendar.get(Calendar.MONTH), newCalendar.get(Calendar.DAY_OF_MONTH));

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_fetch_call_type, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        super.onOptionsItemSelected(item);
        switch (item.getItemId()) {
            case R.id.change_number:
                SharedPreferences settings = getSharedPreferences("MyPrefsFile", 0); // 0 - for private mode
                SharedPreferences.Editor editor = settings.edit();
                editor.putBoolean("hasLoggedIn", false);
                editor.commit();
                Intent intent = new Intent(FetchCallTypeActivity.this, PhoneNumber.class);
                startActivity(intent);
                break;
        }
        return true;
    }

    public void operatorNotFound(){
        Intent intent = new Intent(FetchCallTypeActivity.this , OperatorNotFound.class);
        startActivity(intent);
    }

    @Override
    public void onClick(View v) {
        if(v == fromDate){
            fromDatePickerDialog.show();
            return;
        }

        AsyncTask<String, String, Void> task = new AsyncTask<String, String, Void>() {

            protected void onPreExecute() {

                super.onPreExecute();

                // set the drawable as progress drawavle

                progBar = (ProgressBar) findViewById(R.id.lp);
                progBar.setVisibility(View.VISIBLE);
                progBar.setIndeterminate(true);
                nonPressed.setEnabled(false);
                nonPressed.setVisibility(View.INVISIBLE);
                fetchButton.setEnabled(false);
                fetchButton.setVisibility(View.INVISIBLE);

                pressed.setVisibility(View.VISIBLE);


                pBar = (ArcProgress) findViewById(R.id.arc_progress);
                pBar2 = (ArcProgress) findViewById(R.id.arc_progress2);
                lp = (ProgressBar) findViewById(R.id.linearProgressBar1);
                lp2 = (ProgressBar) findViewById(R.id.linearProgressBar2);
                pBar.setMax((int) mlog.totalCallDuration);
                pBar.setProgress(0);
                pBar.setVisibility(View.VISIBLE);
                pBar.setBottomTextSize(40);

                lp.setIndeterminate(false);
                lp.setMax((int) mlog.totalCallDuration);
                lp.setVisibility(View.VISIBLE);
                lp.setProgress(0);
                lp.setTag("Same Operator");
                pBar2.setMax((int) mlog.totalCallDuration);
                pBar2.setProgress(0);
                pBar2.setVisibility(View.VISIBLE);
                pBar2.setBottomTextSize(30);
                pBar2.setSuffixText("mins");
                pBar.setSuffixText("mins");

                lp2.setIndeterminate(false);
                lp2.setMax((int) mlog.totalCallDuration);
                lp2.setVisibility(View.VISIBLE);
                lp2.setProgress(0);
                lp2.setTag("Same Operator");

            }

            @Override
            protected Void doInBackground(String... params) {
                getCallLogDetails();
                return null;
            }

            private void getCallLogDetails() {
                //check STD/ISD
                int sz = mlog.callList.size();
                try {



                } catch (Exception e) {
                    Toast.makeText(mContext,"Looks like your Internet Connection is shaky!",Toast.LENGTH_SHORT);
                    flag = 1;

                    Thread.currentThread().interrupt();
                    Intent intent = new Intent(mContext, NoInternet.class);
                    mContext.startActivity(intent);
                    e.printStackTrace();

                }
                Log.d("FetchPlans", "total Local  Same Operator calls: " + local.sameOperator.minutes + " " + local.sameOperator.seconds);
                Log.d("FetchPlans", "total STD  Same Operator calls: " + std.sameOperator.minutes + " " + std.sameOperator.seconds);
                Log.d("FetchPlans", "total Local  all Operator calls: " + local.allCalls.minutes + " " + local.allCalls.seconds);
                Log.d("FetchPlans", "total STD  all Operator calls: " + std.allCalls.minutes + " " + std.allCalls.seconds);


            }

            @Override
            protected void onProgressUpdate(String... values) {
                super.onProgressUpdate(values);
                if (values[0].equals("0")) {
                    pBar.setProgress(pBar.getProgress() + Integer.parseInt(values[1]));
                    lp.setProgress(lp.getProgress() + Integer.parseInt(values[1]));
                } else if (values[0].equals("2")) {
                    pBar2.setProgress(pBar2.getProgress() + Integer.parseInt(values[1]));
                    lp2.setProgress(lp2.getProgress() + Integer.parseInt(values[1]));
                } else if (values[0].equals("1")) {
                    pBar.setProgress(pBar.getProgress() + Integer.parseInt(values[1]));
                } else
                    pBar2.setProgress(pBar2.getProgress() + Integer.parseInt(values[1]));

            }

            protected void onPostExecute(Void v) {
                //parse JSON data
                if (flag == 0) {
                    progBar.setVisibility(View.INVISIBLE);


                    pressed.setVisibility(View.INVISIBLE);
                    pressed.setEnabled(false);
                    fetchButton.setVisibility(View.VISIBLE);
                    fetchButton.setEnabled(true);
                    fetchButton.setOnClickListener(new OnClickListener() {
                        @Override
                        public void onClick(View v) {


                            Intent intent = new Intent(getApplicationContext(), ScreenSlideActivity.class);
                            intent.putExtra("logData", mlog);
                            startActivity(intent);


                        }

                        });
                }
            }

        };
    }
}


